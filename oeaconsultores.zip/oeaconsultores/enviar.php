<?php
$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$mensaje = $_POST['mensaje'];

$mensajec = ("Nombre: ".$nombre."\n"."Correo: ".$correo."\n"."Teléfono: ".$telefono."\n"."Mensaje: ".$mensaje);

mail('jose.nilo1997@gmail.com', "Formulario de contacto", $mensajec);
redirect("/index.html", 'refresh');
?>